var localesex = {
    timeSong: "{0}",
    nameSong: "...",
    nothing: "Nothing to play",

    playing: "Playing right now",
};

var refreshTime = 200;