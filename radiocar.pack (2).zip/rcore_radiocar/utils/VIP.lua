-- if you want this script for... lets say like only vip, edit this function.
function YourSpecialPermission()
    return true
end