This is just simple marker that can be lock for job / can be seen by everyone

What it will do?

It can install radio for $$$ so great for mechanic roleplay.


---

What to change in config.lua in resource rcore_radiocar?

Config.OnlyCarWhoHaveRadio = true

---