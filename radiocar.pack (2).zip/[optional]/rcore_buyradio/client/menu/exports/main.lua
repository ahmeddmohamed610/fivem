function CloseAll()
    SendNUIMessage({ type = "ui", status = false })
end