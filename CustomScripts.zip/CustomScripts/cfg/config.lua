cfg = {}

--when someone dies, it notifies everyone in the server
cfg.deathMessages = true

--it shows the direction (N,S,W,E) and the name of the street that you are.
cfg.streetNames = true

--when someone is talking, a text shows up saying the name of the person(s) that is(are) talking
cfg.playerTalking = true

--shows a speedometer in mph
cfg.speedometer = true